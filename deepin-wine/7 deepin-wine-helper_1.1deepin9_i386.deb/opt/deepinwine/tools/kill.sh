#!/bin/bash

APP_NAME="QQ"

get_bottle_path_by_process_id()
{
    PID_LIST="$1"
    PREFIX_LIST=""

    for pid_var in $PID_LIST ; do
        WINE_PREFIX=$(xargs -0 printf '%s\n' < /proc/$pid_var/environ | grep WINEPREFIX)
        WINE_PREFIX=${WINE_PREFIX##*=}
        #echo "found $pid_var : $WINE_PREFIX"
        for path in $(echo -e $PREFIX_LIST) ; do
            if [[ $path == "$WINE_PREFIX" ]]; then
                WINE_PREFIX=""
            fi
        done
        PREFIX_LIST+="\n$WINE_PREFIX"
    done
    echo -e $PREFIX_LIST | grep $HOME
}

get_bottle_path_by_process_name()
{
    PID_LIST=$(ps -ef | grep -E -i "c:.*${1}|d:.*${1}|e:.*${1}|f:.*${1}" | grep -v grep | awk '{print $2}')
    get_bottle_path_by_process_id "$PID_LIST"
}

get_bottle_path()
{
    if [ -d "$1" ]; then
         echo "$1"
         return 0
     fi

    if [ -d "$HOME/.deepinwine/$1" ]; then
        echo "$HOME/.deepinwine/$1"
        return 0
    fi
    get_bottle_path_by_process_name "$1"
}

kill_app()
{
    for path in $(get_bottle_path $1); do
        if [[ $path == *"deepinwine"* ]]; then
            echo "kill $path deepinwine"
            env WINEPREFIX="$path" /usr/lib/i386-linux-gnu/deepin-wine/wineserver -k
        elif [[ $path == *"cxoffice"* ]]; then
            echo "kill $path cxoffice"
            env WINEPREFIX="$path" /opt/cxoffice/bin/wineserver -k
        else
            echo "unkown ${path}"
            env WINEPREFIX="$path" /usr/lib/i386-linux-gnu/deepin-wine/wineserver -k
        fi
    done
}

get_tray_window()
{
    /opt/deepinwine/tools/get_tray_window | grep window_id: | awk -F: '{print $2}'
}

get_stacking_window()
{
    xprop -root _NET_CLIENT_LIST_STACKING | awk -F# '{print $2}' | sed -e 's/, / /g'
}

get_window_pid()
{
    for winid in $(echo "$1" | sed -e 's/ /\n/g') ;
    do
        xprop -id $winid _NET_WM_PID | awk -F= '{print $2}'
    done
}

get_window_bottle()
{
    #echo "get_window_bottle $1"
    PID_LIST=$(get_window_pid "$1")
    #echo "get_window_bottle pid list: $PID_LIST"
    get_bottle_path_by_process_id "$PID_LIST"
}

get_active_bottles()
{
    TRAYWINDOWS=$(get_tray_window)
    STACKINGWINDOWS=$(get_stacking_window)
    get_window_bottle "$TRAYWINDOWS"
    get_window_bottle "$STACKINGWINDOWS"
}

kill_exit_block_app()
{
    TAGBOTTLE=$(get_bottle_path_by_process_name $1)
    echo "tag bottle: $TAGBOTTLE"
    ACTIVEBOTTLES=$(get_active_bottles)
    echo "active bottles: $ACTIVEBOTTLES"

    if [[ "$ACTIVEBOTTLES" != *"$TAGBOTTLE"* ]]; then
         kill_app "$TAGBOTTLE"
    fi
}

#get_active_bottles
#exit

if [ -n "$1" ]; then
    APP_NAME="$1"
fi

if [ "$2" = "block" ]; then
    kill_exit_block_app $APP_NAME $3
else
    kill_app $APP_NAME
fi

