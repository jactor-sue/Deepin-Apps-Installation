#!/bin/bash

#   Copyright (C) 2016 Deepin, Inc.
#
#   Author:     Li LongYu <lilongyu@linuxdeepin.com>
#               Peng Hao <penghao@linuxdeepin.com>

WINEPREFIX="$HOME/.deepinwine/@public_bottle_name@"
APPDIR="/opt/deepinwine/apps/@public_bottle_name@"
APPVER="@deb_version_string@"
APPTAR="files.7z"
BOTTLENAME=""
WINE_CMD="deepin-wine"

_SetRegistryValue()
{
    env WINEPREFIX="$WINEPREFIX" $WINE_CMD reg ADD "$1" /v "$2" /t $3 /d "$4"
}

_DeleteRegistry()
{
    env WINEPREFIX="$WINEPREFIX" $WINE_CMD reg DELETE "$1" /f
}

_SetOverride()
{
    _SetRegistryValue 'HKCU\Software\Wine\DllOverrides' "$2" REG_SZ "$1"
}

HelpApp()
{
	echo " Extra Commands:"
	echo " -r/--reset     Reset app to fix errors"
	echo " -e/--remove    Remove deployed app files"
	echo " -h/--help      Show program help info"
}
FixLink()
{
    if [ -d ${WINEPREFIX} ]; then
        CUR_DIR=$PWD
        cd "${WINEPREFIX}/dosdevices"
        rm c: z:
        ln -s -f ../drive_c c:
        ln -s -f / z:
        cd $CUR_DIR
        ls -l "${WINEPREFIX}/dosdevices"
    fi
}
urldecode() { : "${*//+/ }"; echo -e "${_//%/\\x}"; }

uridecode()
{
    local path=$(urldecode "$1")
    path=${path/file:\/\//}
    echo $path
}

get_bottle_path_by_process_id()
{
    PID_LIST="$1"
    PREFIX_LIST=""

    for pid_var in $PID_LIST ; do
        WINE_PREFIX=$(xargs -0 printf '%s\n' < /proc/$pid_var/environ | grep WINEPREFIX)
        WINE_PREFIX=${WINE_PREFIX##*=}
        #echo "found $pid_var : $WINE_PREFIX"
        for path in $(echo -e $PREFIX_LIST) ; do
            if [[ $path == "$WINE_PREFIX" ]]; then
                WINE_PREFIX=""
            fi
        done
        PREFIX_LIST+="\n$WINE_PREFIX"
    done
    echo -e $PREFIX_LIST | grep $HOME
}

get_bottle_path_by_process_name()
{
    PID_LIST=$(ps -ef | grep -E -i "c:.*${1}" | grep -v grep | awk '{print $2}')
    get_bottle_path_by_process_id "$PID_LIST"
}

CallYMDY()
{
    SERVER_BOTTLE=$(get_bottle_path_by_process_name sqlservr.exe | grep $WINEPREFIX)
    if [ -z "$SERVER_BOTTLE" ]; then
        echo "Starting SQL Server ..."
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Microsoft SQL Server\\MSSQL\\Binn\\sqlservr.exe" -s MSSQLSERVER &
    else
        echo "SQL Server is running in $SERVER_BOTTLE"
    fi

    if [ "autostart" == "$1" ]; then
        echo "Auto start SQL Server"
    elif [ "tongji" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\旗帜软件\\党内信息管理系统(统计版)\\CReport.exe" &
    elif [ "createdb" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\旗帜软件\\党内信息管理系统(统计版)\\数据库安装\\SetupDb.exe" &
    elif [ "servermanger" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Microsoft SQL Server\\80\\Tools\\Binn\\sqlmangr.exe" /n &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\旗帜软件\\党内信息管理系统(统计版)\\QZCPMIS.exe" &
    fi
}
CallYMGWY()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD uninstaller --list
    elif [ "tongji" == "$1" ]; then
        firefox "http://127.0.0.1:64022/hzbtj" &
    else
        firefox "http://127.0.0.1:64022/hzb" &
    fi
}
CallYMPOPS()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\全国持久性有机污染物统计年报信息管理系统(2017)\\POPs.exe" &
    fi
}
CallYMRLZY()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\人力资源社会保障统计报表系统SMIS2012\\bin\\Omni.exe" &
    fi
}
CallYMDATJ()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        if [ ! -f "$WINEPREFIX/drive_c/Program Files/JoinCheer/全国档案事业统计年报信息管理系统/ReportE.exe" ]; then
            env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\deepin\\install\\setup.exe"
        fi

        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\JoinCheer\\全国档案事业统计年报信息管理系统\\ReportE.exe" &
    fi
}
CallYMWZXX()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\全国政府网站信息报送客户端\\UFReader.exe" &
    fi
}
CallRTX2015()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Tencent\\RTXC\\RTX.exe" &
    fi
}
CallYMRDWS()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\饮用水水源环境基础信息采集系统\\RDWS.exe"  &
    fi
}
CallQQGame()
{
    echo "run $1"
    if [ -f "$WINEPREFIX/drive_c/users/$USER/Application Data/Tencent/QQMicroGameBox/Launch.exe" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\users\\$USER/Application Data\\Tencent\\QQMicroGameBox\\Launch.exe" -/appid:$1 &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\QQMicroGameBoxMini\\QQMGameBoxUpdater.exe" -action:force_download -appid:$1 -pid:8 -bin_version:1.1.2.4 -loginuin: &
    fi
}
CallWXWork()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        /opt/deepinwine/tools/kill.sh WXWork.exe block

        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\WXWork\\WXWork.exe" &
    fi
}
CallRTX2009()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Tencent\\RTXC\\RTX.exe" &
    fi
}
CallIrfanView()
{
    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else
        OPEN_FILE=$(uridecode $1)
        if [ -f "$OPEN_FILE" ]; then
            OPEN_FILE=$(realpath "$OPEN_FILE")
            OPEN_FILE="z:$OPEN_FILE"
            echo "fond file $OPEN_FILE"
            OPEN_FILE=$(echo $OPEN_FILE | sed -e 's/\//\\\\/g')
        fi

        echo "file path: $OPEN_FILE"
        if [ -n "$OPEN_FILE" ]; then
            env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\IrfanView\\i_view32.exe" "$OPEN_FILE" &
        else
            env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\IrfanView\\i_view32.exe" &
        fi
    fi
}
CallQQ()
{
    if [ ! -f "$WINEPREFIX/../.QQ_run" ]; then
        echo "first run time"
        /opt/deepinwine/tools/add_hotkeys
        /opt/deepinwine/tools/fontconfig
        touch "$WINEPREFIX/../.QQ_run"
    fi

    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else 
        #Support use native file dialog
        export ATTACH_FILE_DIALOG=1

        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Tencent\\QQ\\Bin\\QQ.exe" &
    fi
}
CallTIM()
{
    if [ ! -f "$WINEPREFIX/../.QQ_run" ]; then
        echo "first run time"
        /opt/deepinwine/tools/add_hotkeys
        /opt/deepinwine/tools/fontconfig
        # If the bottle not exists, run reg may cost lots of times
        # So create the bottle befor run reg
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD uninstaller --list
        touch $WINEPREFIX/../.QQ_run
    fi

    if [ "autostart" == "$1" ]; then
        env WINEPREFIX="$WINEPREFIX" $WINE_CMD /opt/deepinwine/tools/startbottle.exe &
    else 
        #disable Tencent MiniBrowser
        _DeleteRegistry "HKCU\\Software\\Tencent\\MiniBrowser"

        #Support use native file dialog
        export ATTACH_FILE_DIALOG=1

        env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Tencent\\TIM\\Bin\\TIM.exe" &
    fi
}
fun1(){
    xwininfo -root -children | grep Wine | grep -i WeChat | grep 60x60
}
CallWeChat()
{
    EXIT_TIME=$(( $(date +%s) + 100 ))

    _DeleteRegistry "HKCU\\Software\\Tencent\\WeChat" "UpdateFailCnt"
    _DeleteRegistry "HKCU\\Software\\Tencent\\WeChat" "NeedUpdateType"
    rm "${WINEPREFIX}/drive_c/users/${USER}/Application Data/Tencent/WeChat/All Users/config/configEx.ini"

    export DISABLE_RENDER_CLIPBOARD=1
    env WINEPREFIX="$WINEPREFIX" $WINE_CMD "c:\\Program Files\\Tencent\\WeChat\\WeChat.exe" &

    while (( $(date +%s) < $EXIT_TIME )) && (( $(fun1|wc -l) < 1 )); do
        sleep 1
    done

    sleep 3
    fun1 |\
    while read line
    do
        ID=$(fun1 | awk '{print $1}')
        if [ -n "$(xwininfo -id $ID | grep IsViewable)" ];then
            xdotool windowclose $ID
        fi
    done
}
CallApp()
{
    FixLink
    echo "CallApp $BOTTLENAME $1 $2"
    case $BOTTLENAME in
        "Deepin-QQ")
            CallQQ "$1" "$2"
            ;;
        "Deepin-TIM")
            CallTIM "$1" "$2"
            ;;
        "Deepin-RTX2015")
            CallRTX2015 "$1" "$2"
            ;;
        "Deepin-RTX2009")
            CallRTX2009 "$1" "$2"
            ;;
        "Deepin-IrfanView")
            CallIrfanView "$1" "$2"
            ;;
        "Deepin-YMRDWS")
            CallYMRDWS "$1" "$2"
            ;;
        "Deepin-WeChat")
            CallWeChat "$1" "$2"
            ;;
        "Deepin-wangzhanxinxi")
            CallYMWZXX "$1" "$2"
            ;;
        "Deepin-dangantongji")
            CallYMDATJ "$1" "$2"
            ;;
        "Deepin-renliziyuan")
            CallYMRLZY "$1" "$2"
            ;;
        "Deepin-YMPOPS")
            CallYMPOPS "$1" "$2"
            ;;
        "Deepin-YMDY")
            CallYMDY "$1" "$2"
            ;;
        "Deepin-YMGWY")
            CallYMGWY "$1" "$2"
            ;;
        "Deepin-QQHlddz")
            CallQQGame 363 "$1" "$2"
            ;;
        "Deepin-QQHlmj")
            CallQQGame 1101070761 "$1" "$2"
            ;;
        "Deepin-QQWzry")
            CallQQGame 1106084547 "$1" "$2"
            ;;
        "Deepin-QQMnsj")
            CallQQGame 1105856612 "$1" "$2"
            ;;
        "Deepin-QQBydr")
            CallQQGame 1104632801 "$1" "$2"
            ;;
        "Deepin-QQJlhmjq")
            CallQQGame 1105370739 "$1" "$2"
            ;;
        "Deepin-QQXwsd")
            CallQQGame 1101328322 "$1" "$2"
            ;;
        "Deepin-QQDldl")
            CallQQGame 1105208044 "$1" "$2"
            ;;
        "Deepin-QQSszb")
            CallQQGame 1105640244 "$1" "$2"
            ;;
        "Deepin-QQCszj")
            CallQQGame 1105974527 "$1" "$2"
            ;;
        "Deepin-WXWork")
            CallWXWork "$1" "$2"
            ;;
        *)
            echo "unkown bottle $BOTTLENAME"
            ;;
    esac
}
ExtractApp()
{
	mkdir -p "$1"
	7z x "$APPDIR/$APPTAR" -o"$1"
	mv "$1/drive_c/users/@current_user@" "$1/drive_c/users/$USER"
	sed -i "s#@current_user@#$USER#" $1/*.reg
}
DeployApp()
{
	ExtractApp "$WINEPREFIX"
	echo "$APPVER" > "$WINEPREFIX/PACKAGE_VERSION"
}
RemoveApp()
{
	rm -rf "$WINEPREFIX"
}
ResetApp()
{
	echo "Reset $PACKAGENAME....."
	read -p "*	Are you sure?(Y/N)" ANSWER
	if [ "$ANSWER" = "Y" -o "$ANSWER" = "y" -o -z "$ANSWER" ]; then
		EvacuateApp
		DeployApp
		CallApp
	fi
}
UpdateApp()
{
	if [ -f "$WINEPREFIX/PACKAGE_VERSION" ] && [ "$(cat "$WINEPREFIX/PACKAGE_VERSION")" = "$APPVER" ]; then
		return
	fi
	if [ -d "${WINEPREFIX}.tmpdir" ]; then
		rm -rf "${WINEPREFIX}.tmpdir"
	fi
	ExtractApp "${WINEPREFIX}.tmpdir"
	/opt/deepinwine/tools/updater -s "${WINEPREFIX}.tmpdir" -c "${WINEPREFIX}" -v
	rm -rf "${WINEPREFIX}.tmpdir"
	echo "$APPVER" > "$WINEPREFIX/PACKAGE_VERSION"
}
RunApp()
{
 	if [ -d "$WINEPREFIX" ]; then
 		UpdateApp
 	else
 		DeployApp
 	fi
    CallApp "$1" "$2"
}

CreateBottle()
{
    if [ -d "$WINEPREFIX" ]; then
        UpdateApp
    else
        DeployApp
    fi
}

if [ -z $1 ] || [ -z $2 ]; then
    echo "Invalid params"
    exit 0
fi

BOTTLENAME="$1"
WINEPREFIX="$HOME/.deepinwine/$1"
APPDIR="/opt/deepinwine/apps/$1"
APPVER="$2"

echo "Run $1 $2"

if [ -z "$3" ]; then
	RunApp
	exit 0
fi
case $3 in
	"-r" | "--reset")
		ResetApp
		;;
	"-c" | "--create")
		CreateBottle
		;;
	"-e" | "--remove")
		RemoveApp
		;;
	"-u" | "--uri")
		RunApp "$4" "$5"
		;;
	"-h" | "--help")
		HelpApp
		;;
	*)
		echo "Invalid option: $3"
		echo "Use -h|--help to get help"
		exit 1
		;;
esac
exit 0
